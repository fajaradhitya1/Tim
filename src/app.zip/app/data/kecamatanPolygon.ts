// Titik-titik buatan untuk membentuk batas wilayah Stabat (contoh)
export const stabatPolygon: [number, number][] = [
  [3.75, 98.43],
  [3.76, 98.45],
  [3.77, 98.47],
  [3.765, 98.48],
  [3.74, 98.49],
  [3.715, 98.475],
  [3.71, 98.46],
  [3.705, 98.44],
  [3.71, 98.425],
  [3.725, 98.42],
  [3.74, 98.425],
  [3.75, 98.43], // Tutup kembali ke titik awal
];
